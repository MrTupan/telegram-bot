copy the file folder to 

GLOBAL 
/storage/emulated/0/Android/data/com.tencent.ig/
KR
/storage/emulated/0/Android/data/com.pung.krmobile/

and paste it